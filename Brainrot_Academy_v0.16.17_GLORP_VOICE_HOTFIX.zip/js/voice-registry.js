export const CHARACTER_VOICES = Object.freeze({
  professor: Object.freeze({
    id: 'professor-brainrot',
    displayName: 'Professor Brainrot',
    role: 'teacher',
    familyRole: 'older-brother',
    sibling: 'glorp',
    voiceDirection: 'Approved custom Option 1: warm, educated, eccentric, theatrical, patient, dryly amused.',
    status: 'speech-bubble-only',
    provider: 'none',
    referenceArchive: 'audio/reference/professor-option1-necessary.mp3',
    localBundleReady: false,
    finalVoiceRequired: false
  }),
  glorp: Object.freeze({
    id: 'glorp',
    displayName: 'Glorp',
    role: 'comic-foil',
    familyRole: 'younger-brother',
    sibling: 'professor',
    voiceDirection: 'Grungle: raspy animated creature, smug, bratty, expressive, comic meltdown energy.',
    status: 'original-bundled-voice',
    provider: 'runway',
    providerVoice: 'Grungle',
    localBundleReady: true,
    finalVoiceRequired: true
  })
});

// Original Glorp voice clips are the only spoken Glorp files in this release.
// The 12 later scripts are kept for compatibility with existing dialogue data,
// but have no word-for-word voice recordings. They use a *related original*
// exclamation instead of the robotic TTS tracks from v0.16.16.
export const GLORP_PRODUCTION_LINES = Object.freeze({
  "Easy. Obviously.": "voice/glorp-wins.mp3",
  "Beginner stuff. I could do this in my sleep.": "voice/glorp-wins.mp3",
  "Told you. Glorp genius.": "voice/glorp-wins.mp3",
  "Okay, that one barely counts.": "voice/question-rigged.mp3",
  "Professor, your questions are suspicious.": "voice/question-rigged.mp3",
  "Stop knowing things!": "voice/stop-knowing-math.mp3",
  "Who wrote these questions?!": "voice/question-rigged.mp3",
  "This game is cheating!": "voice/game-cheating.mp3",
  "Professor! Make them less smart!": "voice/stop-knowing-math.mp3",
  "No! No! No! I demand a rematch!": "voice/what-no.mp3",
  "I was going to say that.": "voice/what-no.mp3",
  "Fine. Maybe you are a little smart.": "voice/question-rigged.mp3",
});

// Legacy export name retained for compatibility with imported game modules.
// These routes now point exclusively to authentic recordings from v0.16.9.
export const GLORP_OFFLINE_RECONSTRUCTIONS = GLORP_PRODUCTION_LINES;

// The launch greeting chooses one existing REAL Glorp voice clip, not a
// synthesized script or a device TTS engine. Spoken text matches the clip.
export const GLORP_AUTHENTIC_OPENINGS = Object.freeze([
  'POTATO!',
  'HOTDOG!',
  "GRANDPA'S WI-FI!",
  "Let's watch videos instead!",
  'MATH IS BROKEN!',
  'HAHA! GLORP WINS!',
]);

export const GLORP_LOCAL_FALLBACKS = Object.freeze({
  'Easy. Obviously.': 'glorp-wins.mp3',
  'Beginner stuff. I could do this in my sleep.': 'glorp-wins.mp3',
  'Told you. Glorp genius.': 'glorp-wins.mp3',
  'Okay, that one barely counts.': 'question-rigged.mp3',
  'Professor, your questions are suspicious.': 'question-rigged.mp3',
  'Stop knowing things!': 'stop-knowing-math.mp3',
  'Who wrote these questions?!': 'question-rigged.mp3',
  'This game is cheating!': 'game-cheating.mp3',
  'Professor! Make them less smart!': 'stop-knowing-math.mp3',
  'No! No! No! I demand a rematch!': 'what-no.mp3',
  'I was going to say that.': 'what-no.mp3',
  'Fine. Maybe you are a little smart.': 'question-rigged.mp3'
});

// Professor is intentionally text-only in v0.11.1. The approved Option 1 sample
// is archived for possible future use, but spelling has no pronunciation audio.
export const LEGACY_GLORP_FILES = Object.freeze({
  'POTATO!': 'voice/potato.mp3',
  'HOTDOG!': 'voice/hotdog.mp3',
  "GRANDPA'S WI-FI!": 'voice/grandpas-wifi.mp3',
  'STOP KNOWING MATH!': 'voice/stop-knowing-math.mp3',
  'HAHA! GLORP WINS!': 'voice/glorp-wins.mp3',
  'THIS GAME IS CHEATING!': 'voice/game-cheating.mp3',
  'WHAT?!': 'voice/what-no.mp3',
  'WHAT?! NO!': 'voice/what-no.mp3',
  "Let's watch videos instead!": 'voice/watch-videos.mp3',
  'That question was rigged!': 'voice/question-rigged.mp3',
  'MATH IS BROKEN!': 'voice/math-broken.mp3'
});

export function getCharacterVoiceSource(speaker, text) {
  if (speaker === 'glorp') {
    const legacyFile=LEGACY_GLORP_FILES[text];
    if (legacyFile) return {type:'local-legacy',file:legacyFile,speaker,text,authentic:true};
    const approximate=GLORP_PRODUCTION_LINES[text];
    if (approximate) return {type:'local-legacy',file:approximate,speaker,text,authentic:true,approximate:true};
  }
  // Professor intentionally remains text-only in the original game design.
  return null;
}

export function isProductionGlorpLine(text) {
  return Boolean(GLORP_PRODUCTION_LINES[text]);
}
