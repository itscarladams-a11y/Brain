import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {GLORP_PRODUCTION_LINES,getCharacterVoiceSource,LEGACY_GLORP_FILES} from '../js/voice-registry.js';
import {GUIDES,LESSONS} from '../js/academy-guides.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const get=p=>fs.readFileSync(path.join(root,p),'utf8');
const allFiles=dir=>fs.readdirSync(path.join(root,dir),{withFileTypes:true}).flatMap(ent=>ent.isDirectory()?allFiles(path.posix.join(dir,ent.name)):[path.posix.join(dir,ent.name)]);
const assets=allFiles('assets');
const runtime=['index.html','manifest.webmanifest','styles.css','sw.js',...allFiles('js'),...assets];
const cache=new Set([...get('sw.js').matchAll(/['"](\.\/[a-zA-Z0-9_.\/-]*)['"]/g)].map(m=>m[1]));

test('entire game runtime ships without remote URLs or network APIs',()=>{
  for(const file of [...allFiles('js'),'index.html','styles.css','sw.js']){
    const source=get(file);
    assert.doesNotMatch(source,/https?:\/\//i,`remote URL inside ${file}`);
    assert.doesNotMatch(source,/\b(?:fetch\s*\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon\s*\()/i,`network API inside ${file}`);
  }
});
test('all static runtime files are cached for the standalone web installation',()=>{
  for(const file of runtime)assert.ok(cache.has(`./${file}`),`offline cache omitted ${file}`);
  assert.ok(cache.has('./'));
  assert.equal(cache.size,runtime.length+1);
});
test('Glorp character voice routes point only at genuine preserved offline clips',()=>{
  for(const [line,local] of Object.entries(GLORP_PRODUCTION_LINES)){
    assert.ok(Object.values(LEGACY_GLORP_FILES).includes(local),line);
    const file='assets/audio/'+local;
    assert.ok(fs.statSync(path.join(root,file)).size>1000);
    assert.ok(cache.has('./'+file));
    assert.equal(getCharacterVoiceSource('glorp',line).file,local);
  }
  for(const file of Object.values(LEGACY_GLORP_FILES))assert.ok(fs.statSync(path.join(root,'assets/audio',file)).size>1000);
  for(const folder of ['assets/audio/voice/intro-reconstruction','assets/audio/voice/offline-reconstruction']){
    assert.equal(fs.existsSync(path.join(root,folder)),false,`synthetic Glorp files present: ${folder}`);
    assert.ok(!get('sw.js').includes(folder));
  }
});
test('all lessons, all tutorial cards and all supported grade quiz narrations are local',()=>{
  for(const [key,item] of Object.entries(GUIDES))item.steps.forEach((_,i)=>{
    assert.ok(cache.has(`./assets/audio/tutorial/guide-${key}-${i}.mp3`));
  });
  for(const [key,item] of Object.entries(LESSONS)){
    item.steps.forEach((_,i)=>assert.ok(cache.has(`./assets/audio/tutorial/lesson-${key}-${i}.mp3`)));
    for(const grade of [1,3,5])assert.ok(cache.has(`./assets/audio/tutorial/lesson-${key}-3-g${grade}.mp3`));
  }
});
test('no Android runtime points at an online hosted server',()=>{
  const config=JSON.parse(get('capacitor.config.json'));
  assert.equal(config.webDir,'www');
  assert.equal(config.server?.url,undefined);
  assert.equal(config.appId,'com.brainrotacademy.app');
});
test('browser and Android web bundles contain byte-for-byte matching local files',()=>{
  for(const file of runtime){
    assert.deepEqual(fs.readFileSync(path.join(root,'www',file)),fs.readFileSync(path.join(root,file)),file);
  }
});
