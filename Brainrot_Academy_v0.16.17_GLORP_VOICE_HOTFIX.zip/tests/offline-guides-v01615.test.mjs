import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GUIDES,LESSONS} from '../js/academy-guides.js';
import {GLORP_OFFLINE_RECONSTRUCTIONS,GLORP_AUTHENTIC_OPENINGS,LEGACY_GLORP_FILES,getCharacterVoiceSource} from '../js/voice-registry.js';
const sw=fs.readFileSync('sw.js','utf8');
const app=fs.readFileSync('js/app.js','utf8');
const css=fs.readFileSync('styles.css','utf8');
test('guided instructions cover each original game mode and subject chooser',()=>{
  for(const id of ['activityScreen','subjectScreen','battleScreen','logicHubScreen','logicLabScreen','patternLabScreen','shapeLabScreen','robotLabScreen','slimeLabScreen','partsSpeechScreen']){
    assert.ok(GUIDES[id],`missing tutorial for ${id}`);
    assert.ok(GUIDES[id].steps.length>=2);
    assert.ok(GUIDES[id].steps.every(x=>x[0].length>4 && x[1].length>25));
  }
});
test('Time, Calendar, Grammar have grade-aware guided practice questions',()=>{
  for(const key of ['time','calendar','grammar']){
    const l=LESSONS[key];assert.equal(l.steps.length,3);
    for(const grade of [1,3,5]){
      const q=l.question(grade);
      assert.equal(q.choices.length,4);
      assert.ok(q.choices.includes(q.answer));
      assert.ok(q.explanation.length>12);
      assert.ok(fs.existsSync(`assets/audio/tutorial/lesson-${key}-3-g${grade}.mp3`));
    }
  }
});
test('all tutorials and narration are packaged for offline service worker',()=>{
  assert.match(sw,/brainrot-academy-v0\.16\.17/);
  assert.match(app,/createAcademyGuides/);
  assert.match(css,/academy-guide-overlay/);
  assert.ok(sw.includes("'./js/academy-guides.js'"));
  for(const [key,item] of Object.entries(GUIDES))item.steps.forEach((_,step)=>{
    const path=`assets/audio/tutorial/guide-${key}-${step}.mp3`;
    assert.ok(fs.statSync(path).size>1500,path);
    assert.ok(sw.includes(`'./${path}'`));
  });
  for(const [key,item] of Object.entries(LESSONS))item.steps.forEach((_,step)=>{
    const path=`assets/audio/tutorial/lesson-${key}-${step}.mp3`;
    assert.ok(fs.statSync(path).size>1500,path);
    assert.ok(sw.includes(`'./${path}'`));
  });
});
test('Glorp dialogue fallback never selects the robotic temporary recordings',()=>{
  assert.equal(Object.keys(GLORP_OFFLINE_RECONSTRUCTIONS).length,12);
  for(const [line,file] of Object.entries(GLORP_OFFLINE_RECONSTRUCTIONS)){
    assert.ok(Object.values(LEGACY_GLORP_FILES).includes(file));
    assert.ok(fs.statSync('assets/audio/'+file).size>1000);
    assert.ok(sw.includes(`'./assets/audio/${file}'`));
    const r=getCharacterVoiceSource('glorp',line);
    assert.equal(r.type,'local-legacy');assert.equal(r.approximate,true);
  }
  assert.equal(getCharacterVoiceSource('professor','The clock says 3:30'),null);
});
test('launch plays existing Glorp voice clips and displays matching captions',()=>{
  assert.match(app,/function playAcademyOpening/);
  assert.match(app,/GLORP_AUTHENTIC_OPENINGS/);
  assert.doesNotMatch(app,/intro-reconstruction/);
  for(const line of GLORP_AUTHENTIC_OPENINGS){
    const p='assets/audio/'+LEGACY_GLORP_FILES[line];
    assert.ok(fs.statSync(p).size>1000,p);
    assert.ok(sw.includes(`'./${p}'`));
  }
});
