# Professor Brainrot Academy v0.16.17 - Authentic Glorp Offline Hotfix

**All bundled gameplay, music, educational narration, tutorials, and saves run offline after installation.** [Offline release notes](OFFLINE_RELEASE_NOTES_v0.16.17.md) include the technical audit and limitations.

# Professor Brainrot Academy v0.16.15 - Offline Tutorial Restoration

Based on the actual restored v0.16.12 source, preserving v0.16.9 art, music, historical gameplay and student save keys.

**New:** first-visit interactive how-to screens for Brain Battle, five Logic Lab games, subject picker and Parts of Speech Lab; replayable HOW TO PLAY buttons; guided Time, Calendar and Grammar lessons with worked examples, grade-sensitive practice questions and optional offline spoken instructions; matching-script locally synthesized placeholders for twelve Glorp lines so the full dialog does not rely on external audio hosts.

**Voice disclaimer:** temporary new speech is synthetic and DOES NOT match the originally approved Grungle voice. Original bundled Glorp recordings remain untouched. The newly generated authentic Grungle intro from the connected Runway account is not present in this ZIP because its downloadable bytes were not available to the packaging environment. The Professor stays text-only as designed. See `RESTORATION_NOTES.md` and `RELEASE_NOTES_v0.16.15.md`.

**APK build:** `npm ci && npm test && bash scripts/setup-codespaces-android.sh && npm run android:build`. Debug APK: `artifacts/Brainrot_Academy_v0.16.17-debug.apk`.

---

> **Restoration note (October 2026):** This full project is based on the actual user-provided v0.16.9 archive, with targeted gameplay patches. It is NOT a byte-identical copy of the unretrieved original v0.16.12, v0.16.13, or v0.16.14 releases. No new Grungle voice recordings have been invented or substituted. The original art, sounds, curriculum, saves, package ID, and game modes are retained. See `RESTORATION_NOTES.md`.

# Brainrot Academy v0.16.12 Restoration Build (based on original v0.16.9)

Brainrot Academy is an offline-capable Grades 1–6 learning game built around Professor Brainrot, Glorp, academic mastery, parent reporting, a five-game Logic Lab, and dedicated academic mini-courses.

## v0.16.9 original highlights
- The approved Bantam Entertainment rooster logo opens the app on a solid black studio screen, without a website address or a white Android launch flash.
- The loading bar measures critical image readiness and app initialization. A retry control appears if the game cannot initialize.
- The original v0.16.9 intro has been retained; the restoration build uses Android version code 1612.

## v0.16.8 testing polish
- Wrong answers stay visible with a clear explanation and a Next Question button.
- Parts of Speech lesson completion requires 75% rather than simply finishing a round.
- Local-date progress tracking, save-failure feedback, and safer offline caching.
- Fresh Codespaces setup with a repeatable Android test APK build. See `FRESH_INSTALL_CODESPACES.md`.

## v0.16.7 Parts of Speech Lab
- Added **Professor Brainrot's Parts of Speech Lab** as a direct activity and dedicated Grammar silo.
- Eight sequenced lessons: Nouns, Verbs, Adjectives, Pronouns, Adverbs, Prepositions, Conjunctions, and Interjections.
- Learners can start at Lesson 1 and continue through all eight in one sitting, resume later, or jump directly to any lesson.
- Added a final **Mixed Mastery** challenge covering all eight parts of speech.
- Added a visible grade pathway: Grade 1 nouns/verbs, Grade 2 adjectives/pronouns, Grade 3 adverbs/prepositions/conjunctions, Grade 4 interjections/mixed work, and Grades 5–6 function/agreement/editing.
- Course answers feed the same Grammar mastery system used by normal grade-level practice.
- Added explicit Interjections mastery metadata under the parts-of-speech domain.
- Added a curated question-queue path to the core game engine so dedicated course lessons stay on-topic while preserving Pause, Back, Home, Restart, Android Back, sound effects, Professor hosting, and Glorp reactions.
- Added a bespoke Parts of Speech course map, teaching panel, progress meter, persistent resume state, lesson best scores, and direct home/activity entry point.

## Logic Lab launch suite
1. Glorp's Lost & Found — deduction / constraints
2. Professor's Pattern Lab — patterns / flexible thinking
3. Professor's Shape Lab — spatial reasoning / mental rotation
4. Glorp's Robot Rescue — sequencing / planning / debugging
5. Glorp's Slime Sweeper — number-clue deduction

Logic Lab progress is intentionally separate from academic mastery.

## Audio design
- Professor Brainrot: speech bubbles only.
- Spelling: visible spelling interactions with no pronunciation audio.
- Glorp: voiced reaction system remains active. Production reactions use local semantic fallbacks when exact remote production media is unavailable.

## Test
```bash
npm test
```

## Android APK build
GitHub Actions and Codespaces can build an Android debug APK. See `GITHUB_APK_BUILD.md`.

```bash
npm ci
npm test
npm run android:build
```

The APK is copied to `artifacts/Brainrot_Academy_v0.16.12-debug.apk`.

## Corrected fresh ZIP for Android
The **COMPLETE** build archive includes original Android launcher icon files, which are required when `npm run android:build` prepares the native project. If starting in a new empty Codespace, run the Android SDK setup script once before building (Codespaces with the included `.devcontainer` can run it automatically).

## v0.16.17 voice restoration
Glorp's 11 temporary computer-voice welcomes and 12 computer-voice reactions have been removed.
The real bundled v0.16.9 Glorp recordings play again, with exact-match authentic reaction
phrases on the main Brain Battle reaction banks. The original 12 later script lines
are not newly recorded and only have approximated fallback sounds if invoked.
The 50 optional prerecorded tutorial narrations are separate from Glorp and remain in place.
Everything needed by the installed game is local. See VOICE_HOTFIX_v0.16.17.md.
